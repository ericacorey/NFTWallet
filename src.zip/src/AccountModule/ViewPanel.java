package AccountModule;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.Vector;

/**
 * File Name: ViewPanel.java
 * Purpose: Creates the java swing UI for the View NFT page
 * @author Ruhuan Liao, Erica Corey, Stefan Mitrovic, Sean Butler, Aaron Montenegro
 * @version 1.1
 */
public class ViewPanel extends JPanel {
    private JLabel viewPanelLabel;

    /**
     *Creates the java swing panel for the View NFT page
     *@param name Name of the system's user
     * @throws SQLException Throws exception if the SQL database cannot be properly handled
     */
    public ViewPanel(String name) throws SQLException {

        // View panel label
//        setLayout(new GridLayout(0, 2));
//        viewPanelLabel = new JLabel("View your NFTs", SwingConstants.CENTER);
//        viewPanelLabel.setFont(new Font("Times", Font.BOLD, 18));
//        add(viewPanelLabel);


        // Display NFT action

        // Connect to the SQL database
        Connection con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/login_demo",
                "root", "root");


        // Retrieve the relevant data from the SQL database using SQL queries
        String query = "SELECT id, name, floor_price FROM NFTs WHERE owner_id = ?";
        PreparedStatement stmt = con.prepareStatement(query);
        stmt.setInt(1, getUserId(con, name));
        ResultSet rs = stmt.executeQuery();

        // Create a new JTable with the ResultSet as its model
        JTable table = new JTable(buildTableModel(rs));

        // Add the JTable to a JScrollPane and add the JScrollPane to the panel
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane);

        // Close the ResultSet, statement, and connection
        rs.close();
        stmt.close();
        con.close();

    }

    /**
     * Returns a table containing a user's connected NFTs and their respective data
     * @param rs Result set containing a user's connected NFTs and their data (id, name, floor_price)
     * @return Returns a DefaultTableModel object containing the user's connected NFTs and their data
     * @throws SQLException Throws exception if the SQL database cannot be properly handled
     */
    private TableModel buildTableModel (ResultSet rs) throws SQLException {
        ResultSetMetaData metaData = rs.getMetaData();

        // Get the column names
        Vector<String> columnNames = new Vector<>();
        int columnCount = metaData.getColumnCount();
        for (int i = 1; i <= columnCount; i++) {
            columnNames.add(metaData.getColumnName(i));
        }

        // Get the data rows
        Vector<Vector<Object>> data = new Vector<>();
        while (rs.next()) {
            Vector<Object> row = new Vector<>();
            for (int i = 1; i <= columnCount; i++) {
                row.add(rs.getObject(i));
            }
            data.add(row);
        }

        // Create a new TableModel with the column names and data rows
        return new DefaultTableModel(data, columnNames);
    }

    /**
     * Returns the userID of a specified user
     * @param con Represents the Connection statement that connects to the database
     * @param name The name of the user whose ID is being retrieved
     * @return Returns the specified user's ID if a valid connection and name are provided
     */
    private int getUserId(Connection con, String name) {
        // replace this with code that gets the user's id from the user_account table

        int userId = -1;
        try {
            String query = "SELECT id FROM user_account WHERE name=?";
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setString(1, name);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                userId = rs.getInt("id");
            }
        } catch (SQLException ex) {
            System.out.println("Error getting user ID: " + ex.getMessage());
        }
        return userId;
    }



}
