package AccountModule;

import javax.swing.*;
import java.awt.*;

/**
 * File Name: ManagePanel.java
 * Purpose: Creates the java swing UI for the Manage NFT page
 * @author Ruhuan Liao, Erica Corey, Stefan Mitrovic, Sean Butler, Aaron Montenegro
 * @version 1.1
 */
public class ManagePanel extends JPanel {

    private JLabel managePanelLabel;

    /**
     * Creates the java swing panel for the Manage NFT page
     * @param name Name of the system's user
     */
    public ManagePanel(String name){
        // Manage panel label
        managePanelLabel = new JLabel("Manage your NFTs", SwingConstants.CENTER);
        managePanelLabel.setFont(new Font("Times", Font.BOLD, 18));
        add(managePanelLabel);
    }
}
